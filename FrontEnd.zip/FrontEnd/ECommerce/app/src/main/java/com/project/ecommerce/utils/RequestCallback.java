package com.project.ecommerce.utils;

public interface RequestCallback {
    void onCallBack();
}
