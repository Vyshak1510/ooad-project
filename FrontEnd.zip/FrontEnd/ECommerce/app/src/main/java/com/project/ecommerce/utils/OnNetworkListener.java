package com.project.ecommerce.utils;

public interface OnNetworkListener {
    void onNetworkConnected();
    void onNetworkDisconnected();
}
